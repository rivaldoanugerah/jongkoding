<div class="footer-instagram-widget">
	<?php dynamic_sidebar( 'instagram-widget' ); ?>
</div>