<div class="STX-form-tab" id="go-pro">
   <div class="STX-h2 STX-content-box-title-bg"><a class="STX-nav-go-pro" href="https://codecanyon.net/item/transition-slider-wordpress-plugin/23531533?ref=creativeinteractivemedia&amp;ref2=wporg" target="_blank" deluminate_imagetype="unknown">GO PRO VERSION!</a></div>

   <div class="STX-publish-table-wrap">
      <table class="form-table" id="go-pro-table">
         <tbody>
         	<tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"></th>
               <td class="STX-td-element"><h2>Transition Slider FREE</h2></td>
               <td class="STX-td-element"><h3>Transition Slider PRO</h3></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"></th>
               <td class="STX-td-element">Installed</td>
				<td class="STX-td-element"><a href="https://codecanyon.net/item/transition-slider-wordpress-plugin/23531533?ref=creativeinteractivemedia" target="_blank">Upgrade now</a></td>            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Unlimited Sliders</h4><p>Create as many sliders as you need</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Regular updates</h4><p>Always up to date with latest version of WordPress</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Smart image and video cropping</h4><p>Images and videos automatically fit any slider size and aspect</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Thumbnail navigation</h4><p>Navigate the slider easily by thumbnails</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Video slides</h4><p>Add mp4 video slides</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Slide layers</h4><p>Add text, image, buttons and video layers with customizable animations to your slides</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Free templates</h4><p>5 Free templates included for easy start</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>FREE slide transitions</h4><p>Slide, Stretch, Roll, Warp, Flash, Fade, Zoom, Crossfade, Line basic</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Premium templates</h4><p>33 high quality templates</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-no"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Premium Layer elements</h4><p>iFrame element, and many more...</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-no"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Mobile and tablet settings</h4><p>Adjust slider and layer settings for mobile and tablet for perfect display on all devices</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-no"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Import / Export sliders</h4><p>Move sliders easily to a different server</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-no"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>PRO slide transitions</h4><p>Line advanced, Crossfade gradient, more coming soom</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-no"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"><h4>Premium support</h4><p>6 months support from purchase with options to extend</p></th>
               <td class="STX-td-element"><i class="dashicons dashicons-no"></i></td>
               <td class="STX-td-element"><i class="dashicons dashicons-yes"></i></td>
            </tr>
            <tr valign="top" class="field-row">
               <th scope="row" class="STX-th-label"></th>
               <td class="STX-td-element">Installed</td>
               <td class="STX-td-element"><a href="https://codecanyon.net/item/transition-slider-wordpress-plugin/23531533?ref=creativeinteractivemedia" target="_blank">Upgrade now</a></td>
            </tr>

         </tbody>
      </table>
   </div>
</div>
<?php
wp_enqueue_style('transitionslider-edit-slider-css');
